# Aquest programa et permet calcular diverses variables teòriques per a la creació d'una piscina semblant a Blue Lagoon.
import Volum as V
import Vestuaris as Ve
import Clor as CL
# constants per a les opcions del menú
Area1=1
Area2=2
Volum=3
Vestuaris=4
Clor=5
QUIT_CHOICE=6
# la funció principal
def main(): 
# selecció de les variables
    choice=0 
    while choice!=QUIT_CHOICE: 
      # mostra el menú
        display_menu() 
      # rebeix la selecció de l'usuari
        choice=int(input("Selecciona el càlcul: ")) 
      # representa la selecció
        if choice==Area1: 
            Longitud1=float(input("Selecciona la longitud (m)"))
            Amplada1=float(input("Selecciona l'amplada (m)"))
            print("L'àrea 1 (m²)", V.Area1(Longitud1,Amplada1))
        elif choice==Area2: 
            Longitud2=float(input("Selecciona la longitud (m)"))
            Amplada2=float(input("Selecciona l'amplada (m)"))
            print("L'àrea 2 (m²)", V.Area2(Longitud2,Amplada2))
        elif choice==Volum: 
            Area1a=float(input("Selecciona l'àrea 1 (m)"))
            Alçada1=float(input("Selecciona l'alçada 1 (m)"))
            Area2a=float(input("Selecciona l'àrea 2 (m)"))
            Alçada2=float(input("Selecciona l'alçada 2 (m)"))
            print("El volum (m³)", V.Volum(Area1a,Alçada1,Area2a,Alçada2))
        elif choice==Vestuaris:
            L1=float(input("Selecciona la longitud 1 (m)"))
            A1=float(input("Selecciona l'amplada 1 (m)"))
            L2=float(input("Selecciona la longitud 2 (m)"))
            A2=float(input("Selecciona l'amplada 2 (m)"))
            print("El nombre de vestuaris", round(Ve.N(L1,A1,L2,A2)))
        elif choice==Clor:
            V=float(input("Selecciona el volum (m³): "))
            print("La quantitat de clor (g)", CL.CL(V))
        elif choice==QUIT_CHOICE: 
             print("Exiting the program...") 
        else:
             print("ERROR: Invalid Selection.") 
 # mostrem el que volem al menú
def display_menu(): 
    print("MENÚ")
    print("1) Àrea piscina 1 (m²)")
    print("2) Àrea piscina 2 (m²)")
    print("3) Volum piscina (m³) *Per normtiva l'alçada no pot ser més gran d'1,2m")
    print("4) El nombre de vestuaris")
    print("5) La quantitat de clor (g)")
    print("6) Sortida")
# call the main function 
main() 