def CL(V):
  return 1.2*V