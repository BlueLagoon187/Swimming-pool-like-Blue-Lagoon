def PDia(VolumPiscina,L1,A1,L2,A2):
    return (3.52 * VolumPiscina) + ((3 * (((L1*A1) + (L2*A2))/500))*(1050/30)) + (134/30) + 60.5