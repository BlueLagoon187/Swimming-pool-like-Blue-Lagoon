# Aquest programa et permet calcular diverses variables teòriques per a la creació d'una piscina semblant a Blue Lagoon.
import NTreballadors as NT
import CostAigua as CA
import PreuDia as Pdia
# constants per a les opcions del menú
NombreTreballadors=9
CAigua=10
PreuDia=11
QUIT_CHOICE=12
# la funció principal
def main(): 
# selecció de les variables
    choice=0 
    while choice!=QUIT_CHOICE: 
      # mostra el menú
        display_menu() 
      # rebeix la selecció de l'usuari
        choice=int(input("Selecciona el càlcul: ")) 
      # representa la selecció
        if choice==NombreTreballadors: 
            A=float(input("Selecciona l'àrea de les piscines (m)"))
            print("El nombre de treballadors és de", NT.Nt(A))
        elif choice==CAigua: 
            V=float(input("Selecciona el volum de les piscines (m³)"))
            print("El nombre de treballadors és de", CA.CA(V))
        elif choice==PreuDia:
            VolumPiscina=float(input("Selecciona el volum de la piscina (m³)"))
            L1=float(input("Selecciona la longitud 1 (m)"))
            A1=float(input("Selecciona l'amplada 1 (m)"))
            L2=float(input("Selecciona la longitud 2 (m)"))
            A2=float(input("Selecciona l'amplada 2 (m)"))
            print("El preu per dia (Є)", Pdia.PDia(VolumPiscina,L1,A1,L2,A2))
        elif choice==QUIT_CHOICE: 
             print("Exiting the program...") 
        else:
             print("ERROR: Invalid Selection.") 
 # mostrem el que volem al menú
def display_menu(): 
    print("MENÚ")
    print("9) El nombre de treballadors")
    print("10) El cost de l'aigua en (Є)")
    print("11) Preu per dia de funcionament (Є)")
    print("12) Sortida")
# call the main function 
main() 