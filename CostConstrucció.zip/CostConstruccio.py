def CostC(L1,A1,L2,A2,Alçada):
    return (8*((L1*A1) + (L2*A2) + (2*L1*Alçada) + (2*L2*Alçada))) + (5*((L1*2) + A1) + ((L2*2) + A2)) + 2480 + (2*1265.49) + (2*608.22)