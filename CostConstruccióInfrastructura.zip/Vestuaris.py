def N(L1,A1,L2,A2):
    return ((L1*A1)+(L2*A2))/0.35