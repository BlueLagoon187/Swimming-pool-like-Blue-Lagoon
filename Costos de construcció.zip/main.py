# Aquest programa et permet calcular diverses variables teòriques per a la creació d'una piscina semblant a Blue Lagoon.
import CostExcavacio as CE
import CostConstruccio as CC
import SouExcavadors as SE
# constants per a les opcions del menú
CostExc=6
SouExc=7
CostConstruccio=8
QUIT_CHOICE=9
# la funció principal
def main(): 
# selecció de les variables
    choice=0 
    while choice!=QUIT_CHOICE: 
      # mostra el menú
        display_menu() 
      # rebeix la selecció de l'usuari
        choice=int(input("Selecciona el càlcul: ")) 
      # representa la selecció
        if choice==CostExc: 
            V=float(input("Selecciona el volum (m³): "))
            print("El cost d'excavació en (Є)", CE.CE(V))
        elif choice==SouExc: 
            Rev=float(input("Selecciona el revestiment interior (m²): "))
            Con=float(input("Selecciona el contorn (m): "))
            print("El cost de la mà d'obra en (Є)", SE.SouExcavadors(Rev,Con))
        elif choice==CostConstruccio:
            Alçada=float(input("Selecciona l'alçada (m)"))
            L1=float(input("Selecciona la longitud 1 (m)"))
            A1=float(input("Selecciona l'amplada 1 (m)"))
            L2=float(input("Selecciona la longitud 2 (m)"))
            A2=float(input("Selecciona l'amplada 2 (m)"))
            print("El preu de construcció de la piscina (Є)", CC.CostC(L1,A1,L2,A2,Alçada))
        elif choice==QUIT_CHOICE: 
             print("Exiting the program...") 
        else:
             print("ERROR: Invalid Selection.") 
 # mostrem el que volem al menú
def display_menu(): 
    print("6) Cost de la excavació (Є)")
    print("7) Cost de la mà d'obra (Є)")
    print("8) El cost de construcció de la piscina (Є)")
    print("9) Sortida")
# call the main function 
main() 