def SouExcavadors(Rev,Con):
    return (8*Rev) + (5*Con)