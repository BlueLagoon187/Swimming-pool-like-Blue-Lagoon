def Nt(A):
  return ((A*3)/500)