def Area1(Longitud1,Amplada1):
    return Longitud1 * Amplada1
def Area2(Longitud2,Amplada2):
    return Longitud2 * Amplada2
def Volum(Area1a,Alçada1,Area2a,Alçada2): 
    return (Area1a*Alçada1)+(Area2a*Alçada2)