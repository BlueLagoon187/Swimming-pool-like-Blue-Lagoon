def CE(V):
    return 4*V
