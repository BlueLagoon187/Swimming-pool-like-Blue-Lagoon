def CA(V):
  return V*3.52