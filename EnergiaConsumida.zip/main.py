# Aquest programa et permet calcular diverses variables teòriques per a la creació d'una piscina semblant a Blue Lagoon.
import EnergiaConsumida as EC
# constants per a les opcions del menú
EnergiaConsumida=12
QUIT_CHOICE=13
# la funció principal
def main(): 
# selecció de les variables
    choice=0 
    while choice!=QUIT_CHOICE: 
      # mostra el menú
        display_menu() 
      # rebeix la selecció de l'usuari
        choice=int(input("Selecciona el càlcul: ")) 
      # representa la selecció
        if choice==EnergiaConsumida: 
            t=float(input("Selecciona el temps que està oberta la piscina (h): "))
            print("La Energia Tèrmica (KJ)", EC.EC(t))
        elif choice==QUIT_CHOICE: 
             print("Exiting the program...") 
        else:
             print("ERROR: Invalid Selection.") 
 # mostrem el que volem al menú
def display_menu(): 
    print("MENÚ")
    print("12) L'energia consumida per la instal·lació (kJ)")
    print("13) Sortida")
# Es truca a la funció principal
main() 